# COMMERCIAL END USER SOFTWARE LICENSE AGREEMENT (EULA)
### RQL AEGIS™ (REHAN QUANT LAB AEGIS) — PROPRIETARY TRADING INFRASTRUCTURE DAEMON
**Licensor:** Rehan Quant Lab (Mohammad Rehan)  
**Applicability:** Self-Hosted / On-Premises Perpetual Software License

---

### 1. GRANT OF LICENSE
Subject to the terms of this Agreement and payment of the one-time license fee, Licensor grants Licensee a perpetual, non-exclusive, non-transferable license to install, execute, and operate the RQL Aegis software strictly on Licensee's own physical computers or private cloud instances.

### 2. NON-ADVISORY & INFRASTRUCTURE CLASSIFICATION
**Licensee explicitly acknowledges and agrees that:**
* RQL Aegis is strictly technical execution middleware, latency monitoring, and risk infrastructure software.
* The software does NOT provide investment advice, trading signals, price forecasts, financial recommendations, or automated strategy alpha.
* Licensor is NOT a registered Investment Adviser (IA), Research Analyst (RA), Broker-Dealer, or Portfolio Manager under SEBI or any other regulatory jurisdiction.
* All trading strategies, parameter settings, capital allocations, and orders routed through the software are the sole, exclusive responsibility of Licensee.

### 3. "AS-IS" WARRANTY DISCLAIMER
THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. LICENSOR DOES NOT WARRANT THAT THE OPERATION OF THE SOFTWARE WILL BE UNINTERRUPTED, BUG-FREE, OR IMMUNE FROM BROKER API LATENCY OR NETWORK OUTAGES.

### 4. LIMITATION OF LIABILITY
UNDER NO CIRCUMSTANCES SHALL LICENSOR BE LIABLE TO LICENSEE OR ANY THIRD PARTY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, PUNITIVE, OR CONSEQUENTIAL DAMAGES, INCLUDING WITHOUT LIMITATION TRADING LOSSES, CAPITAL DEPLETION, MISSED PROFITS, BROKER PENALTIES, OR SYSTEM OUTAGES ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE. IN ALL CASES, LICENSOR'S TOTAL AGGREGATE LIABILITY SHALL BE STRICTLY LIMITED TO THE ACTUAL PURCHASE AMOUNT PAID BY LICENSEE FOR THE SOFTWARE LICENSE.

### 5. DATA PRIVACY INVARIANT
RQL Aegis operates 100% locally on Licensee's designated hardware. Licensor collects zero trading data, zero order telemetry, zero broker credentials, and zero proprietary algorithmic logic.

---

### 6. OFFICIAL CONTACT & LICENSING DESK
* **Licensor:** Rehan Quant Lab (Mohammad Rehan, Principal Systems Architect)
* **Official Laboratory Web Portal:** [rehanquantlab.com](https://rehanquantlab.com)
* **Official Support & Key Activation Desk:** `founder@rehanquantlab.com`
* **Headquarters:** Patna, Bihar, India
