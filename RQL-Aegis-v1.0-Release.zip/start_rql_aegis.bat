@echo off
cd /d "%~dp0"
title RQL Aegis - Production Trading Risk Daemon
color 0E
echo Starting RQL Aegis Daemon...
if exist "RQL-Aegis.exe" (
    "RQL-Aegis.exe"
) else (
    python run_rql_aegis.py
)
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo [ALERT] RQL Aegis stopped with error code %errorlevel%.
    pause
)
