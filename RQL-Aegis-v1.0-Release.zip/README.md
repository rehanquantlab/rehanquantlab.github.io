# RQL Aegis™ — Deterministic On-Premises Trading Risk Engine
### *Production-Grade Low-Latency Risk Daemon for Proprietary Desks & Systematic Algorithmic Traders*

**Product:** RQL Aegis™ (Commercial Release v1.0)  
**Architect:** Mohammad Rehan, Principal Quantitative Systems Architect  
**Laboratory:** Rehan Quant Lab (Patna, Bihar, India)  
**Official Portal:** [rehanquantlab.com](https://rehanquantlab.com)  
**Licensing & Support Desk:** `founder@rehanquantlab.com`  

---

## 1. Executive Summary & Core Problems Solved

Algorithmic trading desks face critical operational vulnerabilities when routing orders through standard retail APIs:

1. **Silent Socket Disconnections:** Broker WebSocket connections drop silently mid-session. Stop-loss orders fail to register, resulting in catastrophic unmonitored drawdowns.
2. **Proprietary Alpha Leaks to Cloud SaaS:** Storing proprietary trading algorithms on shared multi-tenant cloud platforms exposes alpha to IP theft, co-location latency penalties, and broker credential leakage.
3. **Volatility Spikes & Execution Slippage:** During sudden regime shifts or volatility spikes, naive algorithms execute standard position sizes into thinning order books, triggering severe market impact.
4. **State Amnesia on Process Interruption:** Unhandled OS exceptions, unexpected reboots, or network disconnects wipe in-memory order states, causing duplicate executions and orphaned positions upon restart.

---

## 2. Core Architectural & Mathematical Invariants

RQL Aegis runs strictly **on-premises** on your local workstation or bare-metal VPS, acting as an ultra-low-latency deterministic risk barrier between your algorithmic strategy and your broker APIs:

* **Continuous Volatility Clamping ($\sigma$-Adaptive Sizing):**  
  Dynamically scales order capacity based on realized market volatility ($\sigma$):
  * $\sigma < 15.0$: $1.00\times$ baseline capacity.
  * $15.0 \le \sigma \le 18.0$: Dynamic compression $\kappa = 0.75$ (reduces position size by 25% to offset bid-ask spread expansion).
  * $\sigma > 18.0$: Tail-risk dampening $\kappa = 0.50$ (50% hard capacity clamp & burst order rate-limiting).
* **Cryptographic SHA-256 Write-Ahead Logging (`fsync` Durability):**  
  Every order state transition, execution fill, and cancel is cryptographically hashed with SHA-256 and committed directly to disk using physical `os.fsync` barriers before memory acknowledgment. Guarantees zero ledger amnesia upon hardware power failure.
* **Deterministic Process Supervisor & Idempotent Failover:**  
  Decoupled watchdog daemon operating at 100Hz detects process interruptions or socket termination, restoring idempotent broker connection state in $<3.5\text{s}$ with zero orphaned orders.
* **Zero-Egress Local Architecture:**  
  100% private execution. Zero trading telemetry, zero broker tokens, and zero alpha parameters are transmitted to any third-party server.

---

## 3. Quick Start & Execution Guide

### Option A: Standalone Windows Binary (Recommended)
1. Double-click `start_rql_aegis.bat` (or execute `RQL-Aegis.exe`).
2. The engine will initialize and display your unique **Hardware Machine Identifier** (e.g. `[0B78F950D49FE5C5]`).
3. If running for the first time without an activation key, the engine operates in **Evaluation / Invariant Audit Mode** to verify all local risk checks.
4. To permanently activate your perpetual workstation license:
   * Email your Machine ID to: `founder@rehanquantlab.com`
   * Enter your Ed25519 cryptographic key when prompted on launch.

### Option B: 24/7 Server Daemon Mode (REST Gateway)
For co-located servers (e.g., AWS Mumbai `ap-south-1` near NSE):
1. Install Python 3.10+ dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
2. Launch the server daemon:
   ```powershell
   python server_mode.py
   ```
3. Access the local telemetry and health probe:
   * Health Check: `http://localhost:9099/healthz`
   * Order Execution Gateway: `POST http://localhost:9099/api/v1/route_order`

---

## 4. Configuration Reference (`config.example.yaml`)

Edit `config.example.yaml` to define your risk boundaries:

```yaml
system:
  environment: "PRODUCTION"
  host: "127.0.0.1"
  port: 9099
  wal_storage_path: "data/trade_audit.wal"

risk_limits:
  max_daily_drawdown_inr: 50000.0   # Hard stop: freezes trading if reached
  max_single_order_inr: 200000.0    # Fat-finger protection cap
  vix_circuit_breaker: 24.0         # Full trading halt threshold
  max_orders_per_second: 5          # Burst rate-limiting

volatility_damping:
  vix_elevated_threshold: 15.0     # 25% position size compression
  vix_panic_threshold: 18.0        # 50% position size cap & dampening

broker_connectors:
  primary: "ZERODHA_KITE"           # Options: ZERODHA_KITE, DHAN, INTERACTIVE_BROKERS, SIMULATED
  api_key: "YOUR_BROKER_API_KEY"
  api_secret: "YOUR_BROKER_SECRET"
```

---

## 5. Supported Broker Connectors

* **Zerodha Kite Connect API** (Native WebSocket tick streamer & order routing)
* **Interactive Brokers (IBKR TWS / Gateway API)**
* **Dhan HQ API v2**
* **Fyers API v3**
* **Deterministic Simulation Engine (Local Backtesting & Paper Trading)**

---

## 6. Commercial License & Legal Notice

This software is governed by the terms of the **Commercial End User Software License Agreement (`LICENSE_COMMERCIAL_EULA.md`)**.

* **License Type:** Single Workstation Perpetual License.
* **Warranty:** Delivered "as-is" for technical execution infrastructure. Licensor does not provide investment advice, price predictions, or financial management services.
* **Support:** Direct engineering support from Mohammad Rehan via `founder@rehanquantlab.com`.

---
*Rehan Quant Lab™ — Deterministic Systems & Quantitative Engineering*  
*"Even the word 'Impossible' spells 'I'M POSSIBLE'."*
